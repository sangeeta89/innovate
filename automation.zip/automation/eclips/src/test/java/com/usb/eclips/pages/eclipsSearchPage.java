package com.usb.eclips.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.usb.eclips.eclips.Driver;
import com.usb.eclips.utilities.page;

public class eclipsSearchPage {

	WebDriver driver;
	
	public eclipsSearchPage() throws Exception{
		this.driver= Driver.getdriverinstance();
		PageFactory.initElements(driver, this);	
	}
	
	@FindBy(xpath="//div[@id='TreeWrapperDiv']//a[@href='SEARCH']")
	public WebElement searchlink;
	
	@FindBy(xpath="//input[contains(@data-bind, 'SearchCriteria.ApplicationID')]")
	public WebElement ApplicationID;
	
	@FindBy(xpath="//span[contains(text(), 'Search')]")
	public WebElement Searchbutton;
	
	
	public void searchApplication(String applicationid){
		
		try{
			searchlink.click();
			page.sleep(1200);
			ApplicationID.sendKeys(applicationid);
			page.sleep(500);
			Searchbutton.click();
			System.out.println("App ID search is successful");
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("unable to click Search application");
		}
		
	}
	
	
	
}
