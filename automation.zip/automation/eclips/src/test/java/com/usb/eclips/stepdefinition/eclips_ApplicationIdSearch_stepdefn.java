package com.usb.eclips.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.Page;
import com.usb.eclips.eclips.Driver;
import com.usb.eclips.utilities.page;

import cucumber.api.java.en.Then;

public class eclips_ApplicationIdSearch_stepdefn {

	
	
	@Then("^Navigate to Search Panel left and perform App Id search$")
	public void navigate_to_Search_Panel_left_and_perform_App_Id_search() throws Throwable {
	
		//WebElement web = Driver.getdriverinstance().findElement(By.xpath("//div[@id='TreeWrapperDiv']//a[@href='SEARCH']")); 		
		//page.waitforElementtoappear(web);
		page.sleep(10000);
		Driver.getdriverinstance().findElement(By.xpath("//div[@id='TreeWrapperDiv']//a[@href='SEARCH']")).click();
		
		Driver.getdriverinstance().findElement(By.xpath("//input[contains(@data-bind, 'SearchCriteria.ApplicationID')]")).sendKeys("20192002134055");
	
		Driver.getdriverinstance().findElement(By.xpath("//span[contains(text(), 'Search')]")).click();
		
		
	}

	@Then("^validate the application results displayed based on the search$")
	public void validate_the_application_results_displayed_based_on_the_search() throws Throwable {
	 
	 ///20192002134055
		
		
		
		
	}


}
