package com.usb.eclips.apimodels;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class RequestBody {

	private List<Contacts> contactslist;

	public List<Contacts> getContactslist() {
		return contactslist;
	}

	public void setContactslist(List<Contacts> contactslist) {
		this.contactslist = contactslist;
	}
	

	
	
}
