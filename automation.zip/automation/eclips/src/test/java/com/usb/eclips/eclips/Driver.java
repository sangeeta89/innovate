package com.usb.eclips.eclips;

import java.io.IOException;
import java.nio.file.Paths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Driver {

	private static String g_sDriverLocation = Paths.get(".").toAbsolutePath().normalize().toString();
	private static WebDriver driver;
	
	@SuppressWarnings("deprecation")
	public static WebDriver getdriverinstance() throws IOException{
		if//(driver != null) {//|| RemoteWebDriver != null){
			(driver == null){
			
			DesiredCapabilities cap =  DesiredCapabilities.internetExplorer();
			cap.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");			
			cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			cap.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
			cap.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
			cap.setCapability("ignoreProtectedModeSettings", true);
			cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			
			//cap.setCapability(
			InternetExplorerOptions oOptions = new InternetExplorerOptions(cap);
			System.out.println(g_sDriverLocation);
			//System.setProperty("webdriver.ie.driver", "H:/cucumberAutomationframwork/eclips/src/test/resources/drivers/IE/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", "C:/IEdriverserver/IEDriverServer.exe");
			
			driver = new InternetExplorerDriver(oOptions);
			
				
			return driver;
		}
		
	return driver;	
	}
	
	
	
	
	
}

