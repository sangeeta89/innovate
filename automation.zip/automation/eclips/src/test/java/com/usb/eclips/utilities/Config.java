package com.usb.eclips.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Config {
	
	private static Properties prop = new Properties();
	
	static{
		
		try {
		
			FileInputStream fis = new FileInputStream("src//test//resources//testdata//epConfig.properties");
			prop.load(fis);
			fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static String getconfigproperty(String key){
		
		return prop.getProperty(key);
	}
	
	
	
}
