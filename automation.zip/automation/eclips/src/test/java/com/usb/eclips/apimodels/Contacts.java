package com.usb.eclips.apimodels;

public class Contacts {

	private String Firstname;
	private String Lastname;
	private String PreferredName;
	private int age;
	private String dob;
	private int phoneno;
	private String country;
	
	
	
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getPreferredName() {
		return PreferredName;
	}
	public void setPreferredName(String preferredName) {
		PreferredName = preferredName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(int phoneno) {
		this.phoneno = phoneno;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
		
	
}
