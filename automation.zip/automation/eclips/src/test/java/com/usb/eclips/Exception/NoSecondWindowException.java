package com.usb.eclips.Exception;

import java.io.IOException;
import java.util.jar.JarException;

public class NoSecondWindowException extends RuntimeException {

	
	
	public void depositamt() throws IOException {
		
	}
	
	
}
