package com.usb.eclips.apimodels;

import java.util.List;

public class ContactsList {

	private List<Contacts> contactslist;

	public List<Contacts> getContactslist() {
		return contactslist;
	}

	public void setContactslist(List<Contacts> contactslist) {
		this.contactslist = contactslist;
	}
	
	
	
	
	
	
}
