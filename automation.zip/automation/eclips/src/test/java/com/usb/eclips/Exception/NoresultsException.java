package com.usb.eclips.Exception;

public class NoresultsException extends RuntimeException {
	
	private String message;
	
	
	public void NoresultsException(String message){
		
		System.out.println(message);
	}
	
	
	
	
}
