package com.usb.eclips.stepdefinition;

import org.openqa.selenium.By;

import com.usb.eclips.eclips.Driver;
import com.usb.eclips.pages.StartPage;
import com.usb.eclips.utilities.page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class eclips_Login_Robo_stepdefn {
	
	StartPage sp;
		
	@Given("^launch the Eclips App URL$")
	public void launch_the_Eclips_App_URL() throws Throwable {
		sp = new StartPage();
		
		sp.launchEclipsRobo("https://eclips8t.us.bank-dns.com/support/login");
		
	}

	@Then("^login into the application using the Role credentials$")
	public void login_into_the_application_using_the_Role_credentials() throws Throwable {

	    
	}

	@Then("^use Robo to enter the login credentials$")
	public void use_Robo_to_enter_the_login_credentials() throws Throwable {
		sp = new StartPage();
		sp.Ec_login();
	    
	}

	@Then("^validate the eclips home page displayed successfully$")
	public void validate_the_eclips_home_page_displayed_successfully() throws Throwable {
	    page.sleep(500);
	    Driver.getdriverinstance().findElement(By.xpath("//*[@class='dynatree-container']//a[@href='SEARCH']")).click();
	
	    
	
	}

}
