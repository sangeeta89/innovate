package com.usb.eclips.enums;

public enum SubMenu {

	Menu{
		
		//@Override
		public String navigateSubMenu(){
			
			return "ViewMenu";
		}	
	},
	
	
	File{
		
		//@Override
		public String navigateSubMenu(){
			
			return "ViewFile";
		}	
	}
	
	
}
