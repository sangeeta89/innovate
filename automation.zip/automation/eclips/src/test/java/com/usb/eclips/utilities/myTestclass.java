package com.usb.eclips.utilities;

import java.awt.print.Printable;
import org.junit.Test;

public class myTestclass {

	
	@Test
	public void test(){
		
//		String text = "appppp, aaaaa, askdahkdhaskdjh, wrewewrewrew, ewrewrewrewrewr rewrewrewrew   ";
//		String[] strlist = text.split("\\\\n");
//		
//		System.out.println(strlist[0]);
//		
//		//System.out.println(strlist[1]);
//		//printmsg();	
		
//		page.printmsg("apple");
//		
//		
//		String s1 = "mango";
//		String s2 = "grapes";
//		String s3 = "mango";
//		System.out.println("compare the strings : " + s1.compareTo(s2));
//		System.out.println("compare the strings : " + s1.compareTo(s3));
//		System.out.println("compare the strings : " + s1.equals(s3));
//		System.out.println("compare the strings : " + s1.equalsIgnoreCase(s2));
//		
//		
//		StringBuilder sb = new StringBuilder();
//		
//		page.printmsg("Here is the String append example using builder: "+sb.append("Sachin-").append("Kapil-").append("DEv-").append("gavas"));
//		
//		System.out.println("concate the strings : " + s1.concat(s2));
//		
		DataStorageMap ds = new DataStorageMap();
		String ss = ds.contactLname("apple");
		System.out.println(" here is the name : " + ss);
	
		
		
		
	}
	
	
	
	
	
	
}
