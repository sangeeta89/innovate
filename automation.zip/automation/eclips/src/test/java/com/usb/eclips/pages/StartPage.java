package com.usb.eclips.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.gargoylesoftware.htmlunit.Page;
import com.usb.eclips.eclips.Driver;
import com.usb.eclips.utilities.page;

public class StartPage {
	
	WebDriver driver;
	
	
	@FindBy(id = "Take me to")
	public WebElement takemelink;
	
	@FindBy(xpath="//a[contains(text(),'Office 3')]")
	public WebElement office;
	
	
	public StartPage() throws Exception{
		this.driver= Driver.getdriverinstance();
		PageFactory.initElements(driver, this);	
	}
	
	public void Startapplication(String URL) throws Exception{
		
		Driver.getdriverinstance().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Driver.getdriverinstance().get(URL);
		Driver.getdriverinstance().manage().window().maximize();
		Driver.getdriverinstance().manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
		String title = Driver.getdriverinstance().getTitle();
		System.out.println("Here is the window title : " + title);
		
		page.sleep(2000);
		System.out.println(" wait complete ");
		Robot robo = new Robot();
		System.out.println("using Robo to enter the credentials");
		String userid="eclppm05";
		String pwd="PRFingMGRpw18";
		HashMap<String, String> loginMap = new HashMap<String, String>();
		loginMap.put("username", userid);
		loginMap.put("Pwd", pwd);
		
		System.out.println("user name is :" + loginMap.get("username"));
		StringSelection strselect = new StringSelection(loginMap.get("userid"));
		Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
		clip.setContents(strselect, strselect);
		page.sleep(2000);
		System.out.println("robo activate");
		robo.keyPress(KeyEvent.VK_CONTROL);
		robo.keyPress(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_CONTROL);
		robo.delay(1000);
		
	}
	
public void StartEclips(String URL) throws Exception{
		try{
			
		//Driver.getdriverinstance().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Driver.getdriverinstance().get(URL);
	//	Driver.getdriverinstance().manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
		System.out.println("eclips launched");
		
//		Driver.getdriverinstance().manage().window().maximize();
//		Driver.getdriverinstance().manage().timeouts().pageLoadTimeout(25, TimeUnit.SECONDS);
//		String title = Driver.getdriverinstance().getTitle();
//		System.out.println("Here is the window title : " + title);
//		
		
		}catch(Exception e){
			e.printStackTrace();	
			
		}
	}

	public void launchEclipsRobo(String URL) throws Exception{
		try{
			page.sleep(200);
		Driver.getdriverinstance().get(URL);
		System.out.println(" robo logging into eclips");
		
		}catch(Exception e){
			e.printStackTrace();	
			
		}
	}
			
		
	public void navigatetoOffice() throws Exception{
		
		page.sleep(10);
		//Driver.getdriverinstance().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		page.waitforElementtoappear(takemelink);
		takemelink.click();
		

	String beforehandle = Driver.getdriverinstance().getWindowHandle();
	System.out.println("before handle ; " + beforehandle);
	office.click();
	page.sleep(6000);
	
	System.out.println("window handle size : " + Driver.getdriverinstance().getWindowHandles().size());
	
	 Set<String> aa = Driver.getdriverinstance().getWindowHandles();
	 for(String s :aa){
		 
		 System.out.println("set value is : " + s);
	 }
	 
	
	System.out.println("window handle size : " + Driver.getdriverinstance().getWindowHandles());
	
	
	for(String handles :Driver.getdriverinstance().getWindowHandles()){	
		System.out.println(" all handles : "+handles);
		if(handles!=beforehandle){
			page.sleep(10000);
			Driver.getdriverinstance().switchTo().window(beforehandle);
		}
	}
	
	
	System.out.println("Switched to Second window complete");
	
//	System.out.println("Title1  is : " + Driver.getdriverinstance().getTitle());
//	Driver.getdriverinstance().manage().window().maximize();
//	
//	Driver.getdriverinstance().switchTo().defaultContent();
//	System.out.println("Title 2 is : " + Driver.getdriverinstance().getTitle());
//	takemelink.click();
//	Driver.getdriverinstance().switchTo().window(beforehandle);
//	page.sleep(9000);
//	System.out.println("printing all window handles");
//	
//	
//	page.sleep(5000);
//	
//	Driver.getdriverinstance().switchTo().window(beforehandle);
//	page.sleep(5000);
//	
//	String primwindow = "";
//	Driver.getdriverinstance().switchTo().window(primwindow);
		
	
	}
	
	public void Ec_login() throws AWTException{
	
		Robot robo = new Robot();
		System.out.println("using Robo to enter the credentials");		
		String userid="eclppm05";		
		StringSelection strselect = new StringSelection(userid);
		Clipboard clip = Toolkit.getDefaultToolkit().getSystemClipboard();
		clip.setContents(strselect, strselect);
		robo.keyPress(KeyEvent.VK_CONTROL);
		robo.keyPress(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_CONTROL);
		robo.delay(500);
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		String pwd="PRFingMGRpw18";
		StringSelection strpwd = new StringSelection(pwd);
		Clipboard clipp = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipp.setContents(strpwd, strpwd);
		
		robo.keyPress(KeyEvent.VK_CONTROL);
		robo.keyPress(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_V);
		robo.keyRelease(KeyEvent.VK_CONTROL);
		robo.delay(500);		
		robo.keyPress(KeyEvent.VK_ENTER);
		robo.keyRelease(KeyEvent.VK_ENTER);
	
		
		System.out.println(" robo logged in sucessful");
		
		
	}
	
	
	
	

}
