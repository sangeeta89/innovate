package com.usb.eclips.apimodels;

import java.util.HashMap;

public class Headers {
	
	static HashMap<String, String> header = new HashMap<String, String>();
	
	public static void getheader(){
		
		header.put("contentype", "json");
		header.put("appkey", "123456789");

		
	}

}
