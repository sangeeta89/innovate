package com.usb.eclips.apimodels;

import static com.jayway.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.config.SSLConfig;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

public class RequestRunner {
	
	Response resp;
	ObjectMapper mapper = new ObjectMapper();
	JsonResponse jsonresponse;
	
	public void RunRequest(RequestBody body, String url){
		
		//resp = given().config(new SSLConfig).body(body).contentType(ContentType.JSON).post(url);
		System.out.println("response as String : " + resp.asString());
				
		//jsonresponse = mapper()
				
		
	}
	
	
	public void runtest(){
				
		RequestBody body = new RequestBody();
			Contacts cnt = new Contacts();
			cnt.setCountry("India");
			cnt.setDob("12/23/1980");
			cnt.setFirstname("Surya");
			cnt.setLastname("RAM");
			cnt.setPhoneno(1234567895);
			cnt.setPreferredName("qqewq");
			
			List<Contacts> contactslist = new ArrayList<Contacts>();
			contactslist.add(cnt);		
			body.setContactslist(contactslist);
			
		
			List<Contacts> listnew = new ArrayList<Contacts>();
			listnew = body.getContactslist();
			
			System.out.println(" FirstName : " + listnew.get(0));
		
	}
	
	
	@Test
	public void runtestA(){
	
		
		Contacts c = new Contacts();
		c.setFirstname("Machan");
		
		List<Contacts> list = new ArrayList<Contacts>();
		list.add(c);
		
		ContactsList cntlist = new ContactsList();
		cntlist.setContactslist(list);
		
		List<Contacts> cc = new ArrayList<Contacts>(cntlist.getContactslist());
		
		System.out.println(" this is the list name: " +cc.get(0).getFirstname());
		
		
	}
	

}
