package com.usb.eclips.pages;

public class LoginPage {

}
