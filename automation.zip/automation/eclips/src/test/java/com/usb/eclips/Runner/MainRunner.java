package com.usb.eclips.Runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
		
		plugin={"pretty", "html:target/cucumber-reports"},
		features="src/test/resources",
		glue={"com.usb.eclips.stepdefinition"},
		//tags="@regression, @AppidSearch, @smoke",
		tags="@regression",
		monochrome = true,
		dryRun =false
		)


public class MainRunner {

}
