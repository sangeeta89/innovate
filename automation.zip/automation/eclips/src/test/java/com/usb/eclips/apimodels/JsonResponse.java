package com.usb.eclips.apimodels;

public class JsonResponse {
	
	

}
