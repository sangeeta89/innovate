package com.usb.eclips.utilities;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.usb.eclips.eclips.Driver;

public class page {

	private static WebDriver driver;
	
	public static void printmsg(Object text){
		System.out.println(text);
	}
	
	@Test
	public void runtest(){
		//printmsg();
	}
	
	public static void sleep(int seconds){
		try{
				Thread.sleep(seconds);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void waitforElementtoappear(WebElement element){
		try{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void waitforElementtoClickable(WebElement element){
		try{
		WebDriverWait wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void waitforElementtobeSelected(WebElement element){
		try{
		WebDriverWait wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions.elementToBeSelected(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void waitforElementtoDisappear(WebElement element){
		try{
		WebDriverWait wait = new WebDriverWait(driver, 25);
		wait.until(ExpectedConditions.invisibilityOf(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void waitforProcessing(){
		
		try {
			
			while(Driver.getdriverinstance().findElement(By.xpath("//*[text(), 'processing..']")).getText().contains("processing")){	
		
				page.sleep(2000);
						
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void readDatafromTable(){
		
		
		List<HashMap<String, String>> listmap = new ArrayList<HashMap<String, String>>();
		
		String headers = "Name;Dept;Sal;address;phone";
		List<String> empdatalist = new ArrayList<String>();
		empdatalist.add("Mahi");
		empdatalist.add("Finance");
		empdatalist.add("1m");
		empdatalist.add("kovil");
		empdatalist.add("248");
		
		empdatalist.add("sas");
		empdatalist.add("software");
		empdatalist.add("1m");
		empdatalist.add("tut");
		empdatalist.add("777");
		
		empdatalist.add("sakthi");
		empdatalist.add("art");
		empdatalist.add("2m");
		empdatalist.add("kovil");
		empdatalist.add("6666");
		
		empdatalist.add("Laksh");
		empdatalist.add("speaker");
		empdatalist.add("1m");
		empdatalist.add("kova");
		empdatalist.add("6677");
		
		String[] colheaders = headers.split(";"); 
		
		//HashMap<String, String> colMap = new HashMap<String, String>();
		
		
		System.out.println("total column header size : "+ colheaders.length);
		
		HashMap<String, String> rowMap = null; 
		
		for(int i=0;i<empdatalist.size();i++){
						
			rowMap = new HashMap<String, String>();
			
				for(int k=0;k<colheaders.length;k++){

					System.out.println(" Total data list size : " + empdatalist.size());
					
					//System.out.println("column value : "+empdatalist.get(k));
					
					System.out.println("row value : " + empdatalist.get(i));
					rowMap.put(colheaders[k], empdatalist.get(i));
					
					
				}
			
				listmap.add(rowMap);
			}
			
		System.out.println("Data Table values from Map: " + listmap.get(2).get("Sal"));
		System.out.println( "Total records count :  " + listmap.size());
		
		
	}
	
	
	
	
	
	
}
