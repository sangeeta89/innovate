package com.usb.eclips.utilities;

import java.util.HashMap;

public class DataStorageMap {
	
	private static HashMap<String, String> objmap = new HashMap<String, String>();

	public static void addData(String a, String b){
		objmap.put(a, b);
	}
	
	public static String getData(String e){
		return objmap.get(e);
	}
	
	public static String contactLname(String abc){
		return abc;
	}
	
	
	
}
