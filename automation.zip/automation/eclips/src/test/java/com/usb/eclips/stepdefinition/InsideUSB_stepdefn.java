package com.usb.eclips.stepdefinition;

import java.io.IOException;
import java.nio.file.Paths;

import org.junit.Test;

import com.usb.eclips.eclips.Driver;
import com.usb.eclips.enums.SubMenu;
import com.usb.eclips.pages.StartPage;
import com.usb.eclips.utilities.Config;
import com.usb.eclips.utilities.DataStorageMap;

public class InsideUSB_stepdefn {

	
	@Test
	public void runTest() throws Exception{

//		System.out.println(" print values from the config property file : " + Config.getconfigproperty("url"));
//		
//		
//		DataStorageMap.addData("vitaminC", "Guava");
//		
//		System.out.println(DataStorageMap.getData("vitaminC"));		
//		
//		System.out.println("value of enums :" + SubMenu.File.toString());
//	
//		String g_sDriverLocation = Paths.get(".").toAbsolutePath().normalize().toString();		
//		
//		
//		System.out.println(g_sDriverLocation);
		
		//Driver.getdriverinstance().get("https://intranet.us.bank-dns.com/");;
		StartPage sp = new StartPage();
		sp.Startapplication("https://intranet.us.bank-dns.com/");
		
		//sp.takemelink.click();
		
		sp.navigatetoOffice();
		
		
		
	}
	
	
	
	
}
