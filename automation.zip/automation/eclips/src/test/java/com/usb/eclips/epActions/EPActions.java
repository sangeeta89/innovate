package com.usb.eclips.epActions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class EPActions {
	
	private static Actions act;
	static WebDriver driver;
	
	public static void moveToElement(WebElement element){
		act = new Actions(driver);
		act.moveToElement(element).build().perform();
	}
	

	public static void draganddropElement(WebElement srcelement, WebElement trgelement){	
		act = new Actions(driver);
		act.dragAndDrop(srcelement, trgelement);
	}

}
