package com.usb.eclips.stepdefinition;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

import com.usb.eclips.eclips.Driver;
import com.usb.eclips.pages.StartPage;
import com.usb.eclips.utilities.page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class eclips_CreditLimitIncrease_stepdefn {
	
	StartPage sp;
		
	@Given("^Launch the US Bank internal application$")
	public void launch_the_US_Bank_internal_application() throws Throwable {
		sp = new StartPage();
//		sp.StartEclips("https://eclips8t.us.bank-dns.com/support/login");
//		
//		Actions act = new Actions(Driver.getdriverinstance());
//		
//		  Driver.getdriverinstance().switchTo().alert();
//		
//		  System.out.println("Alert switched");
//		  
//		  //.sendKeys("eclpmg10");
//		  PRFingMGRpw18
//		  page.sleep(10);
//		  act.sendKeys("eclpmg10");
//		  act.keyDown(Keys.TAB);
//		  
//		  Driver.getdriverinstance().switchTo().alert().sendKeys("onegin19");
//		  
//		  //act.sendKeys("onegin19");
//		  act.keyDown(Keys.ENTER);
	
		//sp.Startapplication("https://eclips8t.us.bank-	dns.com/support/login");
		
		sp.launchEclipsRobo("https://eclips8t.us.bank-dns.com/support/login");
		
		//sp.takemelink.click();
		
		//sp.navigatetoOffice();

	//page.sleep(300);
	sp.Ec_login();
		
		
	}

	@Then("^Navigate to the URLS$")
	public void navigate_to_the_URLS() throws Throwable {
//	  Actions act = new Actions(Driver.getdriverinstance());
//	  
//	  System.out.println("enter  login credentials");
//	  
//	  
//	  Driver.getdriverinstance().switchTo().alert();
//	  
//	  //.sendKeys("eclpmg10");
//	  
//	  act.sendKeys("eclpmg10");
//	  act.keyDown(Keys.TAB);
//	  
//	  Driver.getdriverinstance().switchTo().alert().sendKeys("onegin19");
//	  
//	  //act.sendKeys("onegin19");
//	  act.keyDown(Keys.ENTER);
//	  
//	  System.out.println("enter  login credentials - completed");
	}
		
		
}
