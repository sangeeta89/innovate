package calculator;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class ConnectToCalculator {
	
	AndroidDriver<MobileElement> driver;
	public void startEmulator() throws MalformedURLException{
		
		DesiredCapabilities cap = new DesiredCapabilities();
		System.out.println("Launching Calculator");
		cap.setCapability("platformName", "Android");
        cap.setCapability("platformVersion", "6.0"); 
        cap.setCapability("deviceName", "emulator-5554"); // Android Emulator
        cap.setCapability("app", "com.android.calculator2");
        cap.setCapability("appActivity", "com.android.calculator2.Calculator");
        cap.setCapability("automationType", "uiAutomator2");
        
        driver = new AndroidDriver<MobileElement> (new URL("http://0.0.0.0:4723/wd/hub"), cap);
	}
	
	public void executeApp() {
		driver.findElement(By.id("com.android.calculator2:id/digit_3")).click();
        driver.findElement(By.id("com.android.calculator2:id/op_add")).click();
        driver.findElement(By.id("com.android.calculator2:id/digit_3")).click();
        driver.findElement(By.id("com.android.calculator2:id/eq")).click();
        
        WebElement results = driver.findElementById("com.android.calculator2:id/formula");
        if(results.getText().equals("6")) {
                 System.out.println("Test Passed");
        }
        else {System.out.println("Test Failed");
         }
	}
	
	public void tearDown() {
		driver.closeApp();
	}
	public static void main(String[] args) throws MalformedURLException {
		ConnectToCalculator ctc=new ConnectToCalculator();
		ctc.startEmulator();
		ctc.executeApp();
		ctc.tearDown();
	}
	
}
