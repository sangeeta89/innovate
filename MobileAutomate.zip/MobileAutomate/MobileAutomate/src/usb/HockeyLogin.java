package usb;


import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class HockeyLogin {

		

	public static void main(String[] args) throws MalformedURLException {
			
			// TODO Auto-generated method stub
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability("platformName", "Android");
	        cap.setCapability("platformVersion", "6.0"); 
	        cap.setCapability("deviceName", "emulator-5554");
	        cap.setCapability("app", "com.usbank.omnimobileapp");
            cap.setCapability("appWaitDuration", 3000);
            cap.setCapability("automationType", "uiAutomator2");
            cap.setCapability("appWaitActivity", "com.usb.module.hello.login.view.LoginActivity");
            cap.setCapability("appActivity", "com.usb.module.environment.ui.SplashActivity");
            
            System.out.println("Launching Hockey");
            AndroidDriver<MobileElement> driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);

            WebDriverWait wait =  new WebDriverWait(driver, 20);
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("usernametextfield")));
            driver.findElement(By.id("usernametextfield")).sendKeys("omavinv");
            driver.findElement(By.id("passwordtextfield")).sendKeys("winter19");
            driver.hideKeyboard();
            driver.findElement(By.id("com.usbank.omnimobileapp:id/loginbutton")).click();
            System.out.println("Successfully logged");
            
            
            
	}
}
